package ex221108;

public class Ex02_변수O리턴X {

	public static void main(String[] args) {

		// sumPrint 메소드 이용해서
		// 3과 5를 더한 결과 출력하기
		sumPrint(3, 5);

	}

	public static void sumPrint(int a, int b) {
		System.out.println(a + b);
	}

}
