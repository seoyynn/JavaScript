package ex221108;

public class Ex04_변수X리턴X {

	public static void main(String[] args) {

		todayWeather();
		
	}
	
	public static void todayWeather() {
	
		System.out.println("오늘날씨 추워용");
		
	}

}
