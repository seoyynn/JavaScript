package ex221108;

public class Ex03_변수X리턴O {

	public static void main(String[] args) {

		System.out.println(getName());
		
	}
	
	public static String getName() {
		return "장서연";
	}

}
